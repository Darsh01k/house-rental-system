using MySqlConnector;

var cs = "Server=localhost;Port=3306;Database=RentalSystemDb;Uid=root;Pwd=;";

using var conn = new MySqlConnection(cs);
await conn.OpenAsync();

Console.WriteLine("Connected to DB. Scanning Rentals for distinct HouseId values...");

var ids = new List<int>();
using (var cmd = new MySqlCommand("SELECT DISTINCT HouseId FROM Rentals;", conn))
using (var reader = await cmd.ExecuteReaderAsync())
{
    while (await reader.ReadAsync())
    {
        if (!reader.IsDBNull(0)) ids.Add(reader.GetInt32(0));
    }
}

Console.WriteLine($"Found {ids.Count} distinct HouseId values.");

foreach (var id in ids)
{
    // Check if a House exists with that Id
    long count = 0;
    using (var cmd = new MySqlCommand("SELECT COUNT(*) FROM Houses WHERE Id = @id;", conn))
    {
        cmd.Parameters.AddWithValue("@id", id);
        count = (long)(await cmd.ExecuteScalarAsync());
    }

    if (count == 0)
    {
        Console.WriteLine($"Inserting placeholder House for Id={id}");
        using var cmd = new MySqlCommand(@"INSERT INTO Houses (Id, Address, Bedrooms, Bathrooms, DailyRate, Status) VALUES (@id, @addr, @beds, @baths, @rate, @status);", conn);
        cmd.Parameters.AddWithValue("@id", id);
        cmd.Parameters.AddWithValue("@addr", $"Imported placeholder for previous Vehicle Id {id}");
        cmd.Parameters.AddWithValue("@beds", 1);
        cmd.Parameters.AddWithValue("@baths", 1);
        cmd.Parameters.AddWithValue("@rate", 0.0m);
        cmd.Parameters.AddWithValue("@status", "Available");
        await cmd.ExecuteNonQueryAsync();
    }
    else
    {
        Console.WriteLine($"House already exists for Id={id}");
    }
}

Console.WriteLine("Done. You can now re-run 'dotnet ef database update' to finish applying migrations.");
