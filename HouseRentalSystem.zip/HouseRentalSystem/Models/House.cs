using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RentalSystem.Models
{
    public class House
    {
        // Primary Key
        public int Id { get; set; }

        // Address of the house (required)
        [Required]
        public string Address { get; set; } = string.Empty;

        // Number of bedrooms
        [Required]
        public int Bedrooms { get; set; }

        // Number of bathrooms
        [Required]
        public int Bathrooms { get; set; }

        // Nightly rate for house rental
        [Required]
        [Column(TypeName = "decimal(18, 2)")]
        public decimal DailyRate { get; set; }

        // Status: Available, Rented, Maintenance
        [Required]
        public string Status { get; set; } = "Available";

        // Navigation property
        public ICollection<Rental> Rentals { get; set; } = new List<Rental>();

        [NotMapped]
        public string AddressSummary => $"{Address} - {Bedrooms}bd/{Bathrooms}ba - {DailyRate:C}";
    }
}
