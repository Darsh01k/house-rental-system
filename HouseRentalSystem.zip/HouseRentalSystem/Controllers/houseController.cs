using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using RentalSystem.Data;
using RentalSystem.Models;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Globalization;
using System.Collections.Generic;

namespace RentalSystem.Controllers
{
    public class HousesController : Controller
    {
        private readonly RentalSystemContext _context;

        public HousesController(RentalSystemContext context)
        {
            _context = context;
        }

        // GET: Houses
        [AllowAnonymous]
        public async Task<IActionResult> Index(string statusFilter)
        {
            IQueryable<House> houses = _context.Houses;

            if (!string.IsNullOrEmpty(statusFilter) && statusFilter != "All")
            {
                houses = houses.Where(v => v.Status == statusFilter);
            }

            ViewBag.CurrentFilter = statusFilter;
            return View(await houses.ToListAsync());
        }

        // GET: Houses/Create
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Houses/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create([Bind("Address,Bedrooms,Bathrooms,DailyRate")] House house)
        {
            if (ModelState.IsValid)
            {
                house.Status = "Available";
                _context.Add(house);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(house);
        }

        // GET: Houses/Edit/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var house = await _context.Houses.FindAsync(id);
            if (house == null) return NotFound();

            return View(house);
        }

        // POST: Houses/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Address,Bedrooms,Bathrooms,DailyRate,Status")] House updatedHouse)
        {
            if (id != updatedHouse.Id) return NotFound();

            if (ModelState.IsValid)
            {
                var house = await _context.Houses
                    .AsNoTracking()
                    .FirstOrDefaultAsync(m => m.Id == id);

                if (house == null) return NotFound();

                if (house.Status == "Rented")
                {
                    if (house.Address != updatedHouse.Address ||
                        house.Bedrooms != updatedHouse.Bedrooms ||
                        house.Bathrooms != updatedHouse.Bathrooms ||
                        house.DailyRate != updatedHouse.DailyRate)
                    {
                        ModelState.AddModelError("", "Cannot change Address, Bedrooms, Bathrooms, or Daily Rate while the house is Rented.");
                        return View(updatedHouse);
                    }

                    if (updatedHouse.Status == "Available" && house.Status == "Rented")
                    {
                        ModelState.AddModelError("Status", "Cannot change Status from Rented back to Available via the Edit form. Use the Rental Return action instead.");
                        return View(updatedHouse);
                    }
                }

                try
                {
                    _context.Entry(updatedHouse).State = EntityState.Modified;
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Houses.Any(e => e.Id == id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(updatedHouse);
        }

        // GET: Houses/Delete/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var house = await _context.Houses
                .FirstOrDefaultAsync(m => m.Id == id);

            if (house == null) return NotFound();

            var activeRentals = await _context.Rentals
                .Where(r => r.HouseId == id && r.RentalEndDate >= DateTime.Today)
                .CountAsync();

            if (house.Status == "Rented" || activeRentals > 0)
            {
                ViewBag.CanDelete = false;
                ViewBag.DeletionReason = "Cannot delete: House is currently Rented or has active, unreturned bookings linked to it.";
            }
            else
            {
                ViewBag.CanDelete = true;
            }

            return View(house);
        }

        // POST: Houses/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var house = await _context.Houses.FindAsync(id);
            if (house == null) return RedirectToAction(nameof(Index));

            var activeRentals = await _context.Rentals
                .Where(r => r.HouseId == id && r.RentalEndDate >= DateTime.Today)
                .CountAsync();

            if (house.Status == "Rented" || activeRentals > 0)
            {
                TempData["ErrorMessage"] = "Deletion failed: House is Rented or has active bookings.";
                return RedirectToAction(nameof(Index));
            }

            _context.Houses.Remove(house);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Houses/Import
        [Authorize(Roles = "Admin")]
        public IActionResult Import()
        {
            return View();
        }

        // POST: Houses/Import
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Import(IFormFile csvFile)
        {
            if (csvFile == null || csvFile.Length == 0)
            {
                ModelState.AddModelError(string.Empty, "Please select a CSV file to import.");
                return View();
            }

            var imported = new List<House>();

            using (var reader = new StreamReader(csvFile.OpenReadStream()))
            {
                while (!reader.EndOfStream)
                {
                    var line = await reader.ReadLineAsync();
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    // Simple CSV parsing: Address,Bedrooms,Bathrooms,DailyRate
                    var parts = line.Split(',');
                    if (parts.Length < 4) continue;

                    var address = parts[0].Trim();
                    var bedrooms = int.TryParse(parts[1].Trim(), out var b) ? b : 0;
                    var bathrooms = int.TryParse(parts[2].Trim(), out var ba) ? ba : 0;
                    var rate = decimal.TryParse(parts[3].Trim(), NumberStyles.Any, CultureInfo.InvariantCulture, out var r) ? r : 0m;

                    if (string.IsNullOrEmpty(address) || bedrooms <= 0) continue;

                    imported.Add(new House
                    {
                        Address = address,
                        Bedrooms = bedrooms,
                        Bathrooms = bathrooms,
                        DailyRate = rate,
                        Status = "Available"
                    });
                }
            }

            if (imported.Count > 0)
            {
                _context.Houses.AddRange(imported);
                await _context.SaveChangesAsync();
                TempData["SuccessMessage"] = $"Imported {imported.Count} houses.";
            }
            else
            {
                TempData["ErrorMessage"] = "No valid houses were found in the uploaded CSV.";
            }

            return RedirectToAction(nameof(Index));
        }
    }
}