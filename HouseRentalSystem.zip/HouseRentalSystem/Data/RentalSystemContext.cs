using Microsoft.EntityFrameworkCore;
using RentalSystem.Models;

namespace RentalSystem.Data
{
    public class RentalSystemContext : DbContext
    {
        public RentalSystemContext(DbContextOptions<RentalSystemContext> options)
            : base(options)
        {
        }

    // DbSets correspond to the tables in your database
    public DbSet<House> Houses { get; set; }
    public DbSet<Rental> Rentals { get; set; }
    }
}