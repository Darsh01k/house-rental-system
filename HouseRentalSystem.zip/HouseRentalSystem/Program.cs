using Microsoft.EntityFrameworkCore;
using RentalSystem.Data;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Add simple cookie authentication for demo purposes. This allows signing in as a User or Admin via a demo login page.
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/AccessDenied";
    });

// --- Database Configuration for XAMPP (MySQL/MariaDB) ---

// 1. Get the connection string from configuration (appsettings.json)
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection") 
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");

// 2. Register the DbContext to use MySQL with Pomelo provider
builder.Services.AddDbContext<RentalSystemContext>(options =>
    options.UseMySql(
        connectionString,
        // Automatically detect the server version (required by Pomelo)
        ServerVersion.AutoDetect(connectionString),
        mysqlOptions =>
        {
            // Enable retries for transient failures (optional but recommended)
            mysqlOptions.EnableRetryOnFailure();
            // Note: Removed the previous CharSetBehavior line that caused the error.
        }
    ));

// --- End Database Configuration ---


var app = builder.Build();

// Seed sample vehicles for demo if none exist.
using (var scope = app.Services.CreateScope())
{
    try
    {
        var db = scope.ServiceProvider.GetRequiredService<RentalSystem.Data.RentalSystemContext>();
        if (!db.Houses.Any())
        {
            db.Houses.AddRange(
                new RentalSystem.Models.House { Address = "123 Main St, Springfield", Bedrooms = 3, Bathrooms = 2, DailyRate = 120m, Status = "Available" },
                new RentalSystem.Models.House { Address = "456 Oak Ave, Riverdale", Bedrooms = 2, Bathrooms = 1, DailyRate = 85m, Status = "Available" },
                new RentalSystem.Models.House { Address = "789 Pine Rd, Lakeside", Bedrooms = 4, Bathrooms = 3, DailyRate = 180m, Status = "Available" },
                new RentalSystem.Models.House { Address = "321 Cedar Ln, Hillcrest", Bedrooms = 2, Bathrooms = 2, DailyRate = 95m, Status = "Available" },
                new RentalSystem.Models.House { Address = "654 Maple Dr, Oakwood", Bedrooms = 5, Bathrooms = 4, DailyRate = 250m, Status = "Available" }
            );
            db.SaveChanges();
        }
    }
    catch (Exception ex)
    {
        // If seeding fails in some environments (missing DB), don't crash the app during startup.
        var logger = scope.ServiceProvider.GetService<ILogger<Program>>();
        logger?.LogWarning(ex, "Seeding sample vehicles failed.");
    }
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();