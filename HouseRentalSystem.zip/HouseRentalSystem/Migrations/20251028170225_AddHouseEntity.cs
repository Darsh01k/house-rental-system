﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RentalSystem.Migrations
{
    /// <inheritdoc />
    public partial class AddHouseEntity : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Attempt to drop the old FK if it exists (some environments may have applied parts of
            // this migration already). Use conditional SQL to avoid errors when the FK is missing.
            migrationBuilder.Sql(@"
                SET @cnt = (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
                            WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'Rentals'
                              AND CONSTRAINT_NAME = 'FK_Rentals_Vehicles_VehicleId');
                SET @sql = IF(@cnt > 0, 'ALTER TABLE `Rentals` DROP FOREIGN KEY `FK_Rentals_Vehicles_VehicleId`;', 'SELECT 1;');
                PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
            ");

            // Drop the Vehicles table if it exists
            migrationBuilder.Sql("DROP TABLE IF EXISTS `Vehicles`;");

            // Rename column VehicleId -> HouseId if the old column still exists
            migrationBuilder.Sql(@"
                SET @cnt = (SELECT COUNT(*) FROM information_schema.COLUMNS
                            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Rentals' AND COLUMN_NAME = 'VehicleId');
                SET @sql = IF(@cnt > 0, 'ALTER TABLE `Rentals` CHANGE `VehicleId` `HouseId` int NOT NULL;', 'SELECT 1;');
                PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
            ");

            // Rename index IX_Rentals_VehicleId to IX_Rentals_HouseId if present
            migrationBuilder.Sql(@"
                SET @cnt = (SELECT COUNT(*) FROM information_schema.STATISTICS
                            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'Rentals' AND INDEX_NAME = 'IX_Rentals_VehicleId');
                SET @sql = IF(@cnt > 0, 'ALTER TABLE `Rentals` RENAME INDEX `IX_Rentals_VehicleId` TO `IX_Rentals_HouseId`;', 'SELECT 1;');
                PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
            ");

            // Create Houses table if it does not already exist (tolerant to partial runs)
            migrationBuilder.Sql(@"
                CREATE TABLE IF NOT EXISTS `Houses` (
                    `Id` int NOT NULL AUTO_INCREMENT,
                    `Address` longtext CHARACTER SET utf8mb4 NOT NULL,
                    `Bedrooms` int NOT NULL,
                    `Bathrooms` int NOT NULL,
                    `DailyRate` decimal(18,2) NOT NULL,
                    `Status` longtext CHARACTER SET utf8mb4 NOT NULL,
                    PRIMARY KEY (`Id`)
                ) CHARACTER SET=utf8mb4;
            ");

            // If there are existing Rentals that reference previous Vehicle IDs
            // ensure there are placeholder House rows for those IDs so the FK can be applied.
            migrationBuilder.Sql(@"
                INSERT INTO Houses (Id, Address, Bedrooms, Bathrooms, DailyRate, Status)
                SELECT DISTINCT r.HouseId, CONCAT('Imported placeholder for id ', r.HouseId), 1, 1, 0.0, 'Available'
                FROM Rentals r
                WHERE r.HouseId IS NOT NULL
                  AND NOT EXISTS (SELECT 1 FROM Houses h WHERE h.Id = r.HouseId);
            ");

            // Add FK from Rentals(HouseId) -> Houses(Id) only if it doesn't already exist
            migrationBuilder.Sql(@"
                SET @cnt = (SELECT COUNT(*) FROM information_schema.REFERENTIAL_CONSTRAINTS
                            WHERE CONSTRAINT_SCHEMA = DATABASE() AND CONSTRAINT_NAME = 'FK_Rentals_Houses_HouseId'
                              AND TABLE_NAME = 'Rentals');
                SET @sql = IF(@cnt = 0,
                    'ALTER TABLE `Rentals` ADD CONSTRAINT `FK_Rentals_Houses_HouseId` FOREIGN KEY (`HouseId`) REFERENCES `Houses`(`Id`) ON DELETE CASCADE;',
                    'SELECT 1;');
                PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
            ");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Rentals_Houses_HouseId",
                table: "Rentals");

            migrationBuilder.DropTable(
                name: "Houses");

            migrationBuilder.RenameColumn(
                name: "HouseId",
                table: "Rentals",
                newName: "VehicleId");

            migrationBuilder.RenameIndex(
                name: "IX_Rentals_HouseId",
                table: "Rentals",
                newName: "IX_Rentals_VehicleId");

            migrationBuilder.CreateTable(
                name: "Vehicles",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    DailyRate = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    HourlyRate = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Make = table.Column<string>(type: "longtext", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Model = table.Column<string>(type: "longtext", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Status = table.Column<string>(type: "longtext", nullable: false)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    Year = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vehicles", x => x.Id);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.AddForeignKey(
                name: "FK_Rentals_Vehicles_VehicleId",
                table: "Rentals",
                column: "VehicleId",
                principalTable: "Vehicles",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
