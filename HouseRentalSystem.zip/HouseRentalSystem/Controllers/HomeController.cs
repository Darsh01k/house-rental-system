using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RentalSystem.Data;
using System.Threading.Tasks;

namespace RentalSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly RentalSystemContext _context;

        public HomeController(RentalSystemContext context)
        {
            _context = context;
        }

        // GET: /Home/Index (Dashboard)
        public async Task<IActionResult> Index()
        {
            // Business Logic: Fetch summary data for the Dashboard (UI Requirement 1)

            // 1. Total Available Houses
            ViewBag.TotalAvailable = await _context.Houses
                .CountAsync(v => v.Status == "Available");

            // 2. Total Current Rentals (Houses with status Rented)
            ViewBag.TotalRented = await _context.Houses
                .CountAsync(v => v.Status == "Rented");

            return View();
        }
        
        // Default Error Action
        public IActionResult Error()
        {
            return View();
        }
    }
}